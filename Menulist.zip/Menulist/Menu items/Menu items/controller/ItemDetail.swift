//
//  ItemDetail.swift
//  iDine
//
//  Created by Reva Dashottar on 13/06/20.
//  Copyright © 2020 Reva Dashottar. All rights reserved.
//

import SwiftUI

struct ItemDetail: View {
    var item: MenuItem
    @EnvironmentObject var order: Order
    @State private var didtap:Bool = false
    var body: some View {
        VStack{
            ZStack(alignment: .bottomTrailing) {
                
                Image(item.mainImage)
                Text("Photo: \(item.photoCredit)")
                .padding(4)
                .background(Color.black)
                .font(.caption)
                .foregroundColor(.white)
                .offset(x:-5, y: -5)
            }
            Text(item.description)
                .padding()
            VStack{
            Button("Order Now !") {
                self.order.add(item: self.item)
                self.didtap.toggle()
                }.font(.headline)
                 .padding()
                 .foregroundColor(Color.white)
                .background(didtap ? Color.gray : Color.black)
                 .cornerRadius(5)
                 .padding()
            Spacer()
        }
        }
        .navigationBarTitle(Text(item.name), displayMode: .inline)
    }
}

struct ItemDetail_Previews: PreviewProvider {
    static let order = Order()
    static var previews: some View {
        NavigationView{
            ItemDetail(item: MenuItem.example).environmentObject(order)
        }
    }
}
