//
//  appview.swift
//  iDine
//
//  Created by Reva Dashottar on 13/06/20.
//  Copyright © 2020 Reva Dashottar. All rights reserved.
//

import SwiftUI

struct appview: View {
    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    Image(systemName: "list.dash").imageScale(.large)
                    Text("Menu")
                }

            orderView()
                .tabItem {
                    Image(systemName: "square.and.pencil").imageScale(.large)
                    Text("Order")
                }
        }
    }
}
struct appview_Previews: PreviewProvider {
    static let order = Order()
    static var previews: some View {
        appview().environmentObject(order)
    }
}
